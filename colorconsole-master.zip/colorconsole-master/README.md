colorconsole
============

Python module for colored text console output

Documentation
=============

The documentation is on the project wiki [click here](https://github.com/lskbr/colorconsole/wiki).

Installation package:
---------------------
Version 0.7.1

[ZIP](https://drive.google.com/uc?export=download&id=0B09NLGtyRsEqUUFqS3Z1QVZVVFU)

[Windows Installer](https://drive.google.com/uc?export=download&id=0B09NLGtyRsEqSE5iNmtuNk5hN1U)

Or using distutils:
easy_install colorconsole

PyPI page:

https://pypi.python.org/pypi/colorconsole/0.7.1
